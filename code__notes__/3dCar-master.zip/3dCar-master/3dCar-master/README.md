## 简介

第一次尝试用[threejs](https://threejs.org) 做3D项目，在模型调试方面与设计师沟通了多次，模型调了43个版本才勉强达到要求。

[连接地址](https://bobby169.github.io/3dCar/)

## 手机扫码

![image](https://raw.githubusercontent.com/bobby169/3dCar/master/img/qrcode.jpg?v=3)

## License MIT